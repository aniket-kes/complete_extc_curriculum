#include <iostream>
using namespace std;

class Power
{
private:
	double a;
	double b;
	double result;

public:
	void raisePower(double a, int b)
	{
		result = 1;
		for(int i = 0; i < b; i++)
		{
			result = result * a;
		}
		cout<<"The answer is : "<<result<<endl;
	}

	void raisePower(double a)
	{
		result = 1;
		for(int i = 0; i < 2; i++)
		{
			result = result * a;
		}
		cout<<"The answer is : "<<result<<endl;
	}

	void raisePower(int a, int b)
	{
		result = 1;
		for(int i = 0; i < b; i++)
		{
			result = result * a;
		}
		cout<<"The answer is : "<<result<<endl;
	}
};

int main()
{
	int a1, b;
	double a;
	string choice;

	Power p;

	cout<<"Please select if you want to find the square of a number or to raise it to a particular power : "<<endl;
	cout<<"Square of a number : Enter S"<<endl;
	cout<<"Power of a number : Enter P"<<endl;
	cin>>choice;

	if(choice == "S")
	{
		cout<<"Enter the base : "<<endl;
		cin>>a;

		p.raisePower(a);
	}

	if(choice == "P")
	{
		cout<<"Enter the base : "<<endl;
		cin>>a;

		cout<<"Enter the exponent : "<<endl;
		cin>>b;

		p.raisePower(a, b);
	}

	return 0;
}